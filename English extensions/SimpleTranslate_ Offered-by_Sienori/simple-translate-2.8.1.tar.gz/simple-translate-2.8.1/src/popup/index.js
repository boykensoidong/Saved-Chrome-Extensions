import React from "react";
import ReactDOM from "react-dom";
import PopupPage from "./components/PopupPage";

ReactDOM.render(<PopupPage />, document.getElementById("root"));
