# BACKERS

Thank you to the awesome backers who supported Simple Translate!

[<img src=https://c5.patreon.com/external/logo/become_a_patron_button.png alt="Became a patreon">](https://www.patreon.com/sienori)
[<img src="other/promotion/badges/paypal.png" alt="Check out with PayPal">](https://www.paypal.me/sienoriExt)

## Backers via Patreon

- kometchtech
- 準平 大坪
- Hans Zhang
- Daisuke SAKAMOTO
- BIlY4kgVBE
- Christian Mårtensson
- shintaks
- Ha Do Manh
- 아영 김
- ovgolovin
- 忠郎 蔡
- alexey vav
- REN YAMAZAKI
- daniel
- Salah Morabit
- Khaled
- [Gyurme](https://github.com/gpg-dev)
- Roman
- Maurizio
- Sutekh Merksmer
- Artem
- infi ziert
- 柱君 叶
- mgulick
- Carol Li
- James
- Quinton Ashley
- Petr Korolev
- Shigeru Tanaka
- Laura Manson
- t_w
- Ryan Reedy
- Milen Tsigomarev
- 名暉 戴
- László Dr. Gerő
- Corko
- Sebastian Fohler
- Olzhas Suleimen
- Allen.YL
- Vladimir Chupin
- Adam Ralph
- Kamran Razvan
- Mitrakov Artem
- kikuchi.takanori
