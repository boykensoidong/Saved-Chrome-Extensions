export enum AutomationMode {
    NONE = '',
    TIME = 'time',
    SYSTEM = 'system',
    LOCATION = 'location',
}
