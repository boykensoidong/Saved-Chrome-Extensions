# Speed reader

Studies have found that by not having to move your eyes to follow the text your reading, you will greatly improve the speed of your reading. This simple application allows you to read a chunk of text simply by flashing words in the same position. Enter your text, click Start and enjoy the read.

**This application is still a work in progress.**

## Why did you make Speed reader?

Mostly because all other speed reading applications i've found lack customization and important usability features such as pause between paragraphs/sentences, but also because i wanted to play with AngularJS, and i had no other project ideas in mind.


Released under the MIT License.

** Known bugs **

- You tell me.