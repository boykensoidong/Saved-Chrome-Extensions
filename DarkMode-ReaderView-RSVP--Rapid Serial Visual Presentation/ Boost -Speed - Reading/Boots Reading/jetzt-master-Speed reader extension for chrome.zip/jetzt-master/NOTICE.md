# Notice

Unless otherwise stated:

```
Copyright 2014, the jetzt contributors
```
