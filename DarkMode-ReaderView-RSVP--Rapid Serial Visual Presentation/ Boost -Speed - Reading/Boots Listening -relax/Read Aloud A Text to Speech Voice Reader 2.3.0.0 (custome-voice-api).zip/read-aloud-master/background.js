try {
  importScripts(
    "js/defaults.js",
    "js/messaging.js",
    "js/content-handlers.js",
    "js/events.js"
  )
}
catch (err) {
  console.error(err)
}
