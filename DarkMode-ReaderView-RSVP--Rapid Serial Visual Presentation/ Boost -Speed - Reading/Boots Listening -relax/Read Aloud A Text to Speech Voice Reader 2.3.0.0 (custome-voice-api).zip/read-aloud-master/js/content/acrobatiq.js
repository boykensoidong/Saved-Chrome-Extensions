//includes html-doc.js

readAloudDoc.ignoreTags = readAloudDoc.ignoreTags.replace(", button,", ",")
