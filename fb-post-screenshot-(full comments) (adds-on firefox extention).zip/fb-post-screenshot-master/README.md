# Facebook Post Screenshot

Firefox Web Extension to save Facebook posts as images.

![Screenshot of post's menu with add-on enabled](https://i.imgur.com/TJAxrYu.png)

More information and download at https://addons.mozilla.org/en-US/firefox/addon/facebook-post-screenshot/
