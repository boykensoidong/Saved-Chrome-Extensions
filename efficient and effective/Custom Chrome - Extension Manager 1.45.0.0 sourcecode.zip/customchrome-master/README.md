# Custom Chrome
A beautifully designed Google Chrome extension manager. Turn on/off your your Chrome extensions quickly and easily without leaving your current tab

![Screenshot of Custom Chrome](https://raw.githubusercontent.com/ciaranmag/customchrome/master/screenshots/sample-screenshot.png)
