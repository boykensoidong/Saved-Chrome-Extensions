
// Using Webpack's ProvidePlugin available on all files without having to import. 
export const gvar = {} 